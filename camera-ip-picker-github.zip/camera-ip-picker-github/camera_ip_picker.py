#!/usr/bin/env python3
import json
import os
import subprocess
import tkinter as tk
from tkinter import ttk, messagebox, simpledialog

APP_TITLE = "Camera IP Picker"
CONFIG_FILE = os.path.expanduser("~/.camera_ip_picker.json")
CONNECTION_NAME = "cam-setup"


def netmask_to_prefix(netmask: str) -> int:
    parts = netmask.strip().split(".")
    if len(parts) != 4:
        raise ValueError("Netmask must have 4 octets.")
    nums = []
    for p in parts:
        n = int(p)
        if n < 0 or n > 255:
            raise ValueError("Invalid netmask octet.")
        nums.append(n)

    bits = "".join(f"{n:08b}" for n in nums)
    if "01" in bits:
        raise ValueError("Netmask is not contiguous.")
    return bits.count("1")


def is_valid_ipv4(ip: str) -> bool:
    parts = ip.strip().split(".")
    if len(parts) != 4:
        return False
    try:
        return all(0 <= int(p) <= 255 for p in parts)
    except ValueError:
        return False


def run_cmd(cmd):
    return subprocess.run(cmd, capture_output=True, text=True)


class CameraIpPickerApp:
    def __init__(self, root: tk.Tk):
        self.root = root
        self.root.title(APP_TITLE)
        self.root.geometry("860x500")

        self.config = self.load_config()
        self.interfaces = self.detect_interfaces()

        default_iface = self.config.get("interface", "")
        if not default_iface and self.interfaces:
            default_iface = self.interfaces[0]

        self.interface_var = tk.StringVar(value=default_iface)
        self.netmask_var = tk.StringVar(value=self.config.get("netmask", "255.255.255.0"))
        self.dns_var = tk.StringVar(value=self.config.get("dns", ""))

        self.build_ui()
        self.refresh_ip_list()

    def load_config(self):
        default = {
            "interface": "",
            "netmask": "255.255.255.0",
            "dns": "",
            "entries": [
                {"ip": "192.168.1.10", "gateway": ""},
                {"ip": "192.168.1.11", "gateway": ""},
                {"ip": "192.168.1.12", "gateway": ""},
                {"ip": "192.168.1.13", "gateway": ""},
            ],
        }
        if not os.path.exists(CONFIG_FILE):
            return default
        try:
            with open(CONFIG_FILE, "r", encoding="utf-8") as f:
                data = json.load(f)

            # Migrate old format if needed
            if "entries" not in data:
                old_ips = data.get("ips", [])
                old_gateway = data.get("gateway", "")
                data["entries"] = [{"ip": ip, "gateway": old_gateway} for ip in old_ips]

            default.update(data)
            return default
        except Exception:
            return default

    def save_config(self):
        cfg = {
            "interface": self.interface_var.get().strip(),
            "netmask": self.netmask_var.get().strip(),
            "dns": self.dns_var.get().strip(),
            "entries": self.get_all_entries(),
        }
        with open(CONFIG_FILE, "w", encoding="utf-8") as f:
            json.dump(cfg, f, indent=2)

    def detect_interfaces(self):
        try:
            result = run_cmd(["nmcli", "-t", "-f", "DEVICE,TYPE,STATE", "device", "status"])
            if result.returncode != 0:
                return []
            lines = [x.strip() for x in result.stdout.splitlines() if x.strip()]
            wired = []
            for line in lines:
                parts = line.split(":")
                if len(parts) >= 2 and parts[1] == "ethernet":
                    wired.append(parts[0])
            return wired
        except Exception:
            return []

    def refresh_interface_dropdown(self):
        self.interfaces = self.detect_interfaces()
        self.interface_combo["values"] = self.interfaces
        if not self.interface_var.get().strip() and self.interfaces:
            self.interface_var.set(self.interfaces[0])

    def build_ui(self):
        main = ttk.Frame(self.root, padding=12)
        main.pack(fill="both", expand=True)

        settings = ttk.LabelFrame(main, text="Network Settings", padding=10)
        settings.pack(fill="x")

        ttk.Label(settings, text="Interface").grid(row=0, column=0, sticky="w", padx=(0, 8), pady=4)
        self.interface_combo = ttk.Combobox(
            settings, textvariable=self.interface_var, values=self.interfaces, width=18, state="normal"
        )
        self.interface_combo.grid(row=0, column=1, sticky="w", pady=4)

        ttk.Button(settings, text="Refresh NICs", command=self.on_refresh_interfaces).grid(
            row=0, column=2, sticky="w", padx=(12, 0), pady=4
        )

        ttk.Label(settings, text="Netmask").grid(row=1, column=0, sticky="w", padx=(0, 8), pady=4)
        ttk.Entry(settings, textvariable=self.netmask_var, width=18).grid(row=1, column=1, sticky="w", pady=4)

        ttk.Label(settings, text="DNS").grid(row=1, column=2, sticky="w", padx=(18, 8), pady=4)
        ttk.Entry(settings, textvariable=self.dns_var, width=24).grid(row=1, column=3, sticky="w", pady=4)

        list_frame = ttk.LabelFrame(main, text="Saved IP / Gateway Entries", padding=10)
        list_frame.pack(fill="both", expand=True, pady=(12, 0))

        columns = ("ip", "gateway")
        self.tree = ttk.Treeview(list_frame, columns=columns, show="headings", height=16)
        self.tree.heading("ip", text="IP Address")
        self.tree.heading("gateway", text="Gateway")
        self.tree.column("ip", width=190, anchor="w")
        self.tree.column("gateway", width=190, anchor="w")
        self.tree.pack(side="left", fill="both", expand=True)
        self.tree.bind("<Double-1>", lambda event: self.apply_selected_entry())

        scrollbar = ttk.Scrollbar(list_frame, orient="vertical", command=self.tree.yview)
        scrollbar.pack(side="left", fill="y")
        self.tree.configure(yscrollcommand=scrollbar.set)

        buttons = ttk.Frame(list_frame)
        buttons.pack(side="left", fill="y", padx=(10, 0))

        ttk.Button(buttons, text="Add Entry", command=self.add_entry).pack(fill="x", pady=4)
        ttk.Button(buttons, text="Edit Selected", command=self.edit_selected_entry).pack(fill="x", pady=4)
        ttk.Button(buttons, text="Remove Selected", command=self.remove_selected_entry).pack(fill="x", pady=4)
        ttk.Button(buttons, text="Apply Selected", command=self.apply_selected_entry).pack(fill="x", pady=4)
        ttk.Button(buttons, text="Return to DHCP", command=self.set_dhcp).pack(fill="x", pady=4)
        ttk.Button(buttons, text="Save Settings", command=self.on_save).pack(fill="x", pady=4)

        tip = (
            "Each saved row keeps its own IP and gateway.\n"
            "Netmask and DNS stay global at the top.\n"
            "Leave gateway blank for direct camera setup if you want.\n"
            "Double-click a row to apply it."
        )
        ttk.Label(main, text=tip, justify="left").pack(anchor="w", pady=(10, 0))

        self.status_var = tk.StringVar(value="Ready")
        ttk.Label(main, textvariable=self.status_var).pack(anchor="w", pady=(8, 0))

    def get_all_entries(self):
        entries = []
        for item_id in self.tree.get_children():
            values = self.tree.item(item_id, "values")
            entries.append({
                "ip": values[0].strip(),
                "gateway": values[1].strip() if len(values) > 1 else "",
            })
        return entries

    def refresh_ip_list(self):
        for item_id in self.tree.get_children():
            self.tree.delete(item_id)

        entries = self.config.get("entries", [])
        entries = sorted(entries, key=lambda x: [int(p) for p in x["ip"].split(".")] if is_valid_ipv4(x["ip"]) else [999,999,999,999])
        for entry in entries:
            self.tree.insert("", "end", values=(entry.get("ip", ""), entry.get("gateway", "")))

    def prompt_for_entry(self, initial_ip="", initial_gateway=""):
        ip = simpledialog.askstring(APP_TITLE, "Enter IPv4 address:\nExample: 192.168.1.20", initialvalue=initial_ip)
        if ip is None:
            return None
        ip = ip.strip()
        if not is_valid_ipv4(ip):
            messagebox.showerror(APP_TITLE, "That is not a valid IPv4 address.")
            return None

        gateway = simpledialog.askstring(
            APP_TITLE,
            "Enter gateway for this IP entry.\nLeave blank if none.",
            initialvalue=initial_gateway
        )
        if gateway is None:
            return None
        gateway = gateway.strip()
        if gateway and not is_valid_ipv4(gateway):
            messagebox.showerror(APP_TITLE, "Gateway is not a valid IPv4 address.")
            return None

        return {"ip": ip, "gateway": gateway}

    def add_entry(self):
        entry = self.prompt_for_entry()
        if not entry:
            return

        existing = self.get_all_entries()
        for row in existing:
            if row["ip"] == entry["ip"] and row["gateway"] == entry["gateway"]:
                messagebox.showinfo(APP_TITLE, "That IP/gateway entry is already in the list.")
                return

        existing.append(entry)
        existing.sort(key=lambda x: [int(p) for p in x["ip"].split(".")])

        for item_id in self.tree.get_children():
            self.tree.delete(item_id)
        for row in existing:
            self.tree.insert("", "end", values=(row["ip"], row["gateway"]))

        self.on_save()

    def edit_selected_entry(self):
        selected = self.tree.selection()
        if not selected:
            messagebox.showinfo(APP_TITLE, "Select a row first.")
            return

        item_id = selected[0]
        values = self.tree.item(item_id, "values")
        entry = self.prompt_for_entry(values[0], values[1] if len(values) > 1 else "")
        if not entry:
            return

        self.tree.item(item_id, values=(entry["ip"], entry["gateway"]))

        entries = self.get_all_entries()
        entries.sort(key=lambda x: [int(p) for p in x["ip"].split(".")])

        for iid in self.tree.get_children():
            self.tree.delete(iid)
        for row in entries:
            self.tree.insert("", "end", values=(row["ip"], row["gateway"]))

        self.on_save()
        self.status_var.set("Edited selected entry")

    def remove_selected_entry(self):
        selected = self.tree.selection()
        if not selected:
            messagebox.showinfo(APP_TITLE, "Select a row first.")
            return
        self.tree.delete(selected[0])
        self.on_save()
        self.status_var.set("Removed selected entry")

    def on_refresh_interfaces(self):
        self.refresh_interface_dropdown()
        if self.interfaces:
            self.status_var.set("Refreshed interfaces")
        else:
            self.status_var.set("No wired interfaces found")

    def on_save(self):
        try:
            if self.netmask_var.get().strip():
                netmask_to_prefix(self.netmask_var.get().strip())
            dns = self.dns_var.get().strip()
            if dns:
                for item in [x.strip() for x in dns.split(",") if x.strip()]:
                    if not is_valid_ipv4(item):
                        raise ValueError(f"DNS '{item}' is not a valid IPv4 address.")

            for entry in self.get_all_entries():
                if not is_valid_ipv4(entry["ip"]):
                    raise ValueError(f"Bad IP in list: {entry['ip']}")
                if entry["gateway"] and not is_valid_ipv4(entry["gateway"]):
                    raise ValueError(f"Bad gateway in list: {entry['gateway']}")

            self.save_config()
            self.status_var.set(f"Saved config to {CONFIG_FILE}")
        except Exception as e:
            messagebox.showerror(APP_TITLE, str(e))

    def apply_selected_entry(self):
        selected = self.tree.selection()
        if not selected:
            messagebox.showinfo(APP_TITLE, "Select a row first.")
            return

        iface = self.interface_var.get().strip()
        if not iface:
            messagebox.showerror(APP_TITLE, "Choose or type an interface first.")
            return

        values = self.tree.item(selected[0], "values")
        ip = values[0].strip()
        gateway = values[1].strip() if len(values) > 1 else ""
        dns = self.dns_var.get().strip()
        netmask = self.netmask_var.get().strip()

        if not is_valid_ipv4(ip):
            messagebox.showerror(APP_TITLE, "Selected IP is invalid.")
            return

        try:
            prefix = netmask_to_prefix(netmask)
        except Exception as e:
            messagebox.showerror(APP_TITLE, f"Bad netmask: {e}")
            return

        if gateway and not is_valid_ipv4(gateway):
            messagebox.showerror(APP_TITLE, "Gateway is not a valid IPv4 address.")
            return

        if dns:
            for item in [x.strip() for x in dns.split(",") if x.strip()]:
                if not is_valid_ipv4(item):
                    messagebox.showerror(APP_TITLE, f"DNS '{item}' is not a valid IPv4 address.")
                    return

        address = f"{ip}/{prefix}"

        cmds = [
            ["nmcli", "connection", "delete", CONNECTION_NAME],
            [
                "nmcli", "connection", "add",
                "type", "ethernet",
                "ifname", iface,
                "con-name", CONNECTION_NAME,
                "ipv4.method", "manual",
                "ipv4.addresses", address,
                "ipv6.method", "ignore",
            ],
        ]

        if gateway:
            cmds[1].extend(["ipv4.gateway", gateway])
        if dns:
            cmds[1].extend(["ipv4.dns", dns])

        cmds.append(["nmcli", "connection", "up", CONNECTION_NAME])

        try:
            for i, cmd in enumerate(cmds):
                result = run_cmd(cmd)
                if result.returncode != 0:
                    if i == 0:
                        continue
                    raise RuntimeError(result.stderr.strip() or result.stdout.strip() or "Unknown nmcli error")

            self.on_save()
            self.status_var.set(f"Applied {ip} / gateway {gateway or '(blank)'} on {iface}")
            messagebox.showinfo(
                APP_TITLE,
                f"Applied:\nIP: {ip}\nNetmask: {netmask}\nGateway: {gateway or '(blank)'}\nDNS: {dns or '(blank)'}"
            )
        except FileNotFoundError:
            messagebox.showerror(APP_TITLE, "nmcli was not found. Install NetworkManager.")
        except Exception as e:
            messagebox.showerror(APP_TITLE, f"Failed to change IP.\n\n{e}")

    def set_dhcp(self):
        iface = self.interface_var.get().strip()
        if not iface:
            messagebox.showerror(APP_TITLE, "Choose or type an interface first.")
            return

        cmds = [
            ["nmcli", "connection", "delete", CONNECTION_NAME],
            [
                "nmcli", "connection", "add",
                "type", "ethernet",
                "ifname", iface,
                "con-name", CONNECTION_NAME,
                "ipv4.method", "auto",
                "ipv6.method", "ignore",
            ],
            ["nmcli", "connection", "up", CONNECTION_NAME],
        ]

        try:
            for i, cmd in enumerate(cmds):
                result = run_cmd(cmd)
                if result.returncode != 0:
                    if i == 0:
                        continue
                    raise RuntimeError(result.stderr.strip() or result.stdout.strip() or "Unknown nmcli error")

            self.on_save()
            self.status_var.set(f"Returned {iface} to DHCP")
            messagebox.showinfo(APP_TITLE, f"{iface} returned to DHCP.")
        except FileNotFoundError:
            messagebox.showerror(APP_TITLE, "nmcli was not found. Install NetworkManager.")
        except Exception as e:
            messagebox.showerror(APP_TITLE, f"Failed to set DHCP.\n\n{e}")


if __name__ == "__main__":
    root = tk.Tk()
    try:
        ttk.Style().theme_use("clam")
    except Exception:
        pass
    app = CameraIpPickerApp(root)
    root.mainloop()

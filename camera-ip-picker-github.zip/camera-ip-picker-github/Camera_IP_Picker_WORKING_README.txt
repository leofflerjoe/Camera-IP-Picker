This one fixes the launcher more aggressively.

What was changed:
- Added a real shell launcher: camera_ip_picker_launcher.sh
- Menu entry now launches the shell script instead of trying to run Python directly
- Added logging to:
  ~/.camera_ip_picker.log
- The app already includes:
  - Add IP
  - Remove Selected
  - Apply Selected
  - Return to DHCP

Install:
1. Unzip this bundle.
2. Open that folder in Terminal.
3. Run:
   chmod +x install_camera_ip_picker_WORKING.sh
   ./install_camera_ip_picker_WORKING.sh

If it still does not open from the menu:
1. Run:
   ~/Apps/camera_ip_picker_launcher.sh
2. If it errors, read:
   ~/.camera_ip_picker.log

If tkinter is missing:
   sudo apt update
   sudo apt install python3-tk

If nmcli is missing:
   sudo apt install network-manager

If it opens but cannot change the IP:
- Use the menu item:
  Camera IP Picker Admin

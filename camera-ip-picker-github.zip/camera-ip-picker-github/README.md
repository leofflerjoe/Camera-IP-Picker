# Camera IP Picker

Simple Python GUI tool for quickly assigning static IPs when setting up cameras.

## Features
- Saved list of IP + gateway entries
- Netmask input
- DNS input
- Interface dropdown with refresh
- Return-to-DHCP button
- Uses NetworkManager / `nmcli`

## Run
```bash
python3 camera_ip_picker.py
```

## Requirements
- Python 3
- tkinter
- NetworkManager (`nmcli`)

On Debian / Ubuntu / Linux Mint:
```bash
sudo apt update
sudo apt install python3-tk network-manager
```

## Notes
- Leave gateway blank for direct camera setup if you do not need one.
- The tool stores its settings in:
  `~/.camera_ip_picker.json`

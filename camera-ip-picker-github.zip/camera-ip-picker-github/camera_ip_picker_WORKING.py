#!/usr/bin/env python3
import json
import os
import platform
import subprocess
import tkinter as tk
from tkinter import ttk, messagebox, simpledialog

APP_TITLE = "Camera IP Picker"
CONFIG_FILE = os.path.expanduser("~/.camera_ip_picker.json")
CONNECTION_NAME = "cam-setup"


def netmask_to_prefix(netmask: str) -> int:
    parts = netmask.strip().split(".")
    if len(parts) != 4:
        raise ValueError("Netmask must have 4 octets.")
    nums = []
    for p in parts:
        n = int(p)
        if n < 0 or n > 255:
            raise ValueError("Invalid netmask octet.")
        nums.append(n)

    bits = "".join(f"{n:08b}" for n in nums)
    if "01" in bits:
        raise ValueError("Netmask is not contiguous.")
    return bits.count("1")


def is_valid_ipv4(ip: str) -> bool:
    parts = ip.strip().split(".")
    if len(parts) != 4:
        return False
    try:
        return all(0 <= int(p) <= 255 for p in parts)
    except ValueError:
        return False


def run_cmd(cmd):
    return subprocess.run(cmd, capture_output=True, text=True, shell=False)


class CameraIpPickerApp:
    def __init__(self, root: tk.Tk):
        self.root = root
        self.os_name = platform.system()
        self.root.title(f"{APP_TITLE} - {self.os_name}")
        self.root.geometry("980x620")
        self.root.minsize(860, 520)

        self.configure_style()

        self.config = self.load_config()
        self.interfaces = self.detect_interfaces()

        default_iface = self.config.get("interface", "")
        if not default_iface and self.interfaces:
            default_iface = self.interfaces[0]

        self.interface_var = tk.StringVar(value=default_iface)
        self.netmask_var = tk.StringVar(value=self.config.get("netmask", "255.255.255.0"))
        self.dns_var = tk.StringVar(value=self.config.get("dns", ""))
        self.status_var = tk.StringVar(value=f"Ready ({self.os_name})")

        self.build_ui()
        self.refresh_entry_list()

    def configure_style(self):
        self.root.configure(bg="#121417")
        style = ttk.Style()
        try:
            style.theme_use("clam")
        except Exception:
            pass

        bg = "#121417"
        panel = "#1B1F24"
        panel2 = "#222831"
        text = "#E8EDF2"
        muted = "#AAB4BE"
        accent = "#3B82F6"
        edge = "#303842"

        style.configure(".", font=("Segoe UI", 10))
        style.configure("App.TFrame", background=bg)
        style.configure("Panel.TLabelframe", background=bg, foreground=text, bordercolor=edge, relief="solid")
        style.configure("Panel.TLabelframe.Label", background=bg, foreground=text, font=("Segoe UI", 10, "bold"))
        style.configure("TLabel", background=bg, foreground=text)
        style.configure("Muted.TLabel", background=bg, foreground=muted)
        style.configure("Header.TLabel", background=bg, foreground=text, font=("Segoe UI", 16, "bold"))
        style.configure("Sub.TLabel", background=bg, foreground=muted, font=("Segoe UI", 10))
        style.configure("TEntry", fieldbackground=panel2, foreground=text, insertcolor=text, bordercolor=edge)
        style.configure("TCombobox", fieldbackground=panel2, foreground=text)
        style.map(
            "TCombobox",
            fieldbackground=[("readonly", panel2)],
            foreground=[("readonly", text)],
        )
        style.configure("Primary.TButton", font=("Segoe UI", 10, "bold"), padding=(12, 8), foreground=text)
        style.configure("Secondary.TButton", padding=(10, 7), foreground=text)
        style.map("Primary.TButton", background=[("active", accent), ("!disabled", accent)])
        style.map("Secondary.TButton", background=[("active", panel2), ("!disabled", panel)])
        style.configure(
            "Treeview",
            background=panel,
            fieldbackground=panel,
            foreground=text,
            bordercolor=edge,
            rowheight=28,
        )
        style.configure("Treeview.Heading", background=panel2, foreground=text, relief="flat", font=("Segoe UI", 10, "bold"))
        style.map("Treeview", background=[("selected", accent)], foreground=[("selected", "#FFFFFF")])

        # Listbox colors still need direct config later.

    def load_config(self):
        default = {
            "interface": "",
            "netmask": "255.255.255.0",
            "dns": "",
            "entries": [
                {"name": "Camera 1", "ip": "192.168.1.10", "gateway": ""},
                {"name": "Camera 2", "ip": "192.168.1.11", "gateway": ""},
                {"name": "Camera 3", "ip": "192.168.1.12", "gateway": ""},
                {"name": "Camera 4", "ip": "192.168.1.13", "gateway": ""},
            ],
        }
        if not os.path.exists(CONFIG_FILE):
            return default
        try:
            with open(CONFIG_FILE, "r", encoding="utf-8") as f:
                data = json.load(f)

            # migrate older formats
            if "entries" not in data:
                old_ips = data.get("ips", [])
                old_gateway = data.get("gateway", "")
                data["entries"] = [{"name": "", "ip": ip, "gateway": old_gateway} for ip in old_ips]

            for entry in data.get("entries", []):
                entry.setdefault("name", "")

            default.update(data)
            return default
        except Exception:
            return default

    def save_config(self):
        cfg = {
            "interface": self.interface_var.get().strip(),
            "netmask": self.netmask_var.get().strip(),
            "dns": self.dns_var.get().strip(),
            "entries": self.get_all_entries(),
        }
        with open(CONFIG_FILE, "w", encoding="utf-8") as f:
            json.dump(cfg, f, indent=2)

    def detect_interfaces(self):
        if self.os_name == "Windows":
            return self.detect_windows_interfaces()
        return self.detect_linux_interfaces()

    def detect_linux_interfaces(self):
        try:
            result = run_cmd(["nmcli", "-t", "-f", "DEVICE,TYPE,STATE", "device", "status"])
            if result.returncode != 0:
                return []
            lines = [x.strip() for x in result.stdout.splitlines() if x.strip()]
            wired = []
            for line in lines:
                parts = line.split(":")
                if len(parts) >= 2 and parts[1] == "ethernet":
                    wired.append(parts[0])
            return wired
        except Exception:
            return []

    def detect_windows_interfaces(self):
        names = []
        try:
            result = subprocess.run(
                ["netsh", "interface", "show", "interface"],
                capture_output=True,
                text=True,
                shell=False,
            )
            if result.returncode == 0:
                lines = [line.rstrip() for line in result.stdout.splitlines() if line.strip()]
                for line in lines:
                    if line.startswith("Admin State") or line.startswith("---"):
                        continue
                    parts = line.split()
                    if len(parts) >= 4:
                        iface_name = " ".join(parts[3:])
                        if iface_name not in names:
                            names.append(iface_name)
        except Exception:
            pass
        return names

    def refresh_interface_dropdown(self):
        self.interfaces = self.detect_interfaces()
        self.interface_combo["values"] = self.interfaces
        if not self.interface_var.get().strip() and self.interfaces:
            self.interface_var.set(self.interfaces[0])

    def build_ui(self):
        outer = ttk.Frame(self.root, style="App.TFrame", padding=16)
        outer.pack(fill="both", expand=True)

        ttk.Label(outer, text="Camera IP Picker", style="Header.TLabel").pack(anchor="w")
        ttk.Label(
            outer,
            text="Fast static IP switching for camera setup on Linux and Windows  Copyright Joe Leoffler 2026",
            style="Sub.TLabel",
        ).pack(anchor="w", pady=(2, 14))

        settings = ttk.LabelFrame(outer, text="Network Settings", style="Panel.TLabelframe", padding=14)
        settings.pack(fill="x")

        ttk.Label(settings, text="Interface").grid(row=0, column=0, sticky="w", padx=(0, 8), pady=6)
        self.interface_combo = ttk.Combobox(
            settings, textvariable=self.interface_var, values=self.interfaces, width=24, state="normal"
        )
        self.interface_combo.grid(row=0, column=1, sticky="w", pady=6)

        ttk.Button(settings, text="Refresh NICs", style="Secondary.TButton", command=self.on_refresh_interfaces).grid(
            row=0, column=2, sticky="w", padx=(12, 0), pady=6
        )

        ttk.Label(settings, text="Netmask").grid(row=1, column=0, sticky="w", padx=(0, 8), pady=6)
        ttk.Entry(settings, textvariable=self.netmask_var, width=24).grid(row=1, column=1, sticky="w", pady=6)

        ttk.Label(settings, text="DNS").grid(row=1, column=2, sticky="w", padx=(18, 8), pady=6)
        ttk.Entry(settings, textvariable=self.dns_var, width=28).grid(row=1, column=3, sticky="w", pady=6)

        list_frame = ttk.LabelFrame(outer, text="Saved IP / Gateway Entries", style="Panel.TLabelframe", padding=14)
        list_frame.pack(fill="both", expand=True, pady=(14, 0))

        columns = ("name", "ip", "gateway")
        self.tree = ttk.Treeview(list_frame, columns=columns, show="headings", height=15)
        self.tree.heading("name", text="Label")
        self.tree.heading("ip", text="IP Address")
        self.tree.heading("gateway", text="Gateway")
        self.tree.column("name", width=210, anchor="w")
        self.tree.column("ip", width=190, anchor="w")
        self.tree.column("gateway", width=190, anchor="w")
        self.tree.pack(side="left", fill="both", expand=True)
        self.tree.bind("<Double-1>", lambda event: self.apply_selected_entry())

        scrollbar = ttk.Scrollbar(list_frame, orient="vertical", command=self.tree.yview)
        scrollbar.pack(side="left", fill="y")
        self.tree.configure(yscrollcommand=scrollbar.set)

        buttons = ttk.Frame(list_frame, style="App.TFrame")
        buttons.pack(side="left", fill="y", padx=(12, 0))

        ttk.Button(buttons, text="Add Entry", style="Primary.TButton", command=self.add_entry).pack(fill="x", pady=4)
        ttk.Button(buttons, text="Edit Selected", style="Secondary.TButton", command=self.edit_selected_entry).pack(fill="x", pady=4)
        ttk.Button(buttons, text="Remove Selected", style="Secondary.TButton", command=self.remove_selected_entry).pack(fill="x", pady=4)
        ttk.Button(buttons, text="Apply Selected", style="Primary.TButton", command=self.apply_selected_entry).pack(fill="x", pady=4)
        ttk.Button(buttons, text="Return to DHCP", style="Secondary.TButton", command=self.set_dhcp).pack(fill="x", pady=4)
        ttk.Button(buttons, text="Save Settings", style="Secondary.TButton", command=self.on_save).pack(fill="x", pady=4)

        info = (
            "Each saved row keeps its own IP and gateway. "
            "Netmask and DNS stay global at the top. "
            "Leave gateway blank for direct camera setup if needed."
        )
        ttk.Label(outer, text=info, style="Muted.TLabel", wraplength=900, justify="left").pack(anchor="w", pady=(12, 6))

        footer = ttk.Frame(outer, style="App.TFrame")
        footer.pack(fill="x", pady=(4, 0))
        ttk.Label(footer, textvariable=self.status_var, style="Muted.TLabel").pack(side="left")
        ttk.Label(footer, text="Copyright Joe Leoffler", style="Muted.TLabel").pack(side="right")

    def get_all_entries(self):
        entries = []
        for item_id in self.tree.get_children():
            values = self.tree.item(item_id, "values")
            entries.append({
                "name": values[0].strip() if len(values) > 0 else "",
                "ip": values[1].strip() if len(values) > 1 else "",
                "gateway": values[2].strip() if len(values) > 2 else "",
            })
        return entries

    def refresh_entry_list(self):
        for item_id in self.tree.get_children():
            self.tree.delete(item_id)

        entries = self.config.get("entries", [])
        def sort_key(x):
            ip = x.get("ip", "")
            if is_valid_ipv4(ip):
                return [int(p) for p in ip.split(".")]
            return [999, 999, 999, 999]

        entries = sorted(entries, key=sort_key)
        for entry in entries:
            self.tree.insert("", "end", values=(entry.get("name", ""), entry.get("ip", ""), entry.get("gateway", "")))

    def prompt_for_entry(self, initial_name="", initial_ip="", initial_gateway=""):
        name = simpledialog.askstring(APP_TITLE, "Enter a label for this entry.\nExample: Red Building", initialvalue=initial_name)
        if name is None:
            return None
        name = name.strip()

        ip = simpledialog.askstring(APP_TITLE, "Enter IPv4 address:\nExample: 192.168.1.20", initialvalue=initial_ip)
        if ip is None:
            return None
        ip = ip.strip()
        if not is_valid_ipv4(ip):
            messagebox.showerror(APP_TITLE, "That is not a valid IPv4 address.")
            return None

        gateway = simpledialog.askstring(
            APP_TITLE,
            "Enter gateway for this IP entry.\nLeave blank if none.",
            initialvalue=initial_gateway
        )
        if gateway is None:
            return None
        gateway = gateway.strip()
        if gateway and not is_valid_ipv4(gateway):
            messagebox.showerror(APP_TITLE, "Gateway is not a valid IPv4 address.")
            return None

        return {"name": name, "ip": ip, "gateway": gateway}

    def add_entry(self):
        entry = self.prompt_for_entry()
        if not entry:
            return

        existing = self.get_all_entries()
        for row in existing:
            if row["ip"] == entry["ip"] and row["gateway"] == entry["gateway"]:
                messagebox.showinfo(APP_TITLE, "That IP/gateway entry is already in the list.")
                return

        existing.append(entry)
        existing.sort(key=lambda x: [int(p) for p in x["ip"].split(".")])

        for item_id in self.tree.get_children():
            self.tree.delete(item_id)
        for row in existing:
            self.tree.insert("", "end", values=(row["name"], row["ip"], row["gateway"]))

        self.on_save()

    def edit_selected_entry(self):
        selected = self.tree.selection()
        if not selected:
            messagebox.showinfo(APP_TITLE, "Select a row first.")
            return

        item_id = selected[0]
        values = self.tree.item(item_id, "values")
        entry = self.prompt_for_entry(
            values[0] if len(values) > 0 else "",
            values[1] if len(values) > 1 else "",
            values[2] if len(values) > 2 else "",
        )
        if not entry:
            return

        self.tree.item(item_id, values=(entry["name"], entry["ip"], entry["gateway"]))

        entries = self.get_all_entries()
        entries.sort(key=lambda x: [int(p) for p in x["ip"].split(".")])

        for iid in self.tree.get_children():
            self.tree.delete(iid)
        for row in entries:
            self.tree.insert("", "end", values=(row["name"], row["ip"], row["gateway"]))

        self.on_save()
        self.status_var.set("Edited selected entry")

    def remove_selected_entry(self):
        selected = self.tree.selection()
        if not selected:
            messagebox.showinfo(APP_TITLE, "Select a row first.")
            return
        self.tree.delete(selected[0])
        self.on_save()
        self.status_var.set("Removed selected entry")

    def on_refresh_interfaces(self):
        self.refresh_interface_dropdown()
        if self.interfaces:
            self.status_var.set(f"Refreshed interfaces ({self.os_name})")
        else:
            self.status_var.set(f"No interfaces found ({self.os_name})")

    def on_save(self):
        try:
            if self.netmask_var.get().strip():
                netmask_to_prefix(self.netmask_var.get().strip())
            dns = self.dns_var.get().strip()
            if dns:
                for item in [x.strip() for x in dns.split(",") if x.strip()]:
                    if not is_valid_ipv4(item):
                        raise ValueError(f"DNS '{item}' is not a valid IPv4 address.")

            for entry in self.get_all_entries():
                if not is_valid_ipv4(entry["ip"]):
                    raise ValueError(f"Bad IP in list: {entry['ip']}")
                if entry["gateway"] and not is_valid_ipv4(entry["gateway"]):
                    raise ValueError(f"Bad gateway in list: {entry['gateway']}")

            self.save_config()
            self.status_var.set(f"Saved config to {CONFIG_FILE}")
        except Exception as e:
            messagebox.showerror(APP_TITLE, str(e))

    def apply_selected_entry(self):
        selected = self.tree.selection()
        if not selected:
            messagebox.showinfo(APP_TITLE, "Select a row first.")
            return

        iface = self.interface_var.get().strip()
        if not iface:
            messagebox.showerror(APP_TITLE, "Choose or type an interface first.")
            return

        values = self.tree.item(selected[0], "values")
        label = values[0].strip() if len(values) > 0 else ""
        ip = values[1].strip() if len(values) > 1 else ""
        gateway = values[2].strip() if len(values) > 2 else ""
        dns = self.dns_var.get().strip()
        netmask = self.netmask_var.get().strip()

        if not is_valid_ipv4(ip):
            messagebox.showerror(APP_TITLE, "Selected IP is invalid.")
            return

        try:
            if self.os_name == "Windows":
                self.apply_windows_static(iface, ip, netmask, gateway, dns)
            else:
                self.apply_linux_static(iface, ip, netmask, gateway, dns)
            self.on_save()
            self.status_var.set(f"Applied {label or ip} on {iface}")
            messagebox.showinfo(
                APP_TITLE,
                f"Applied:\nLabel: {label or '(none)'}\nIP: {ip}\nNetmask: {netmask}\nGateway: {gateway or '(blank)'}\nDNS: {dns or '(blank)'}"
            )
        except Exception as e:
            messagebox.showerror(APP_TITLE, f"Failed to change IP.\n\n{e}")

    def apply_linux_static(self, iface, ip, netmask, gateway, dns):
        prefix = netmask_to_prefix(netmask)
        address = f"{ip}/{prefix}"

        cmds = [
            ["nmcli", "connection", "delete", CONNECTION_NAME],
            [
                "nmcli", "connection", "add",
                "type", "ethernet",
                "ifname", iface,
                "con-name", CONNECTION_NAME,
                "ipv4.method", "manual",
                "ipv4.addresses", address,
                "ipv6.method", "ignore",
            ],
        ]

        if gateway:
            cmds[1].extend(["ipv4.gateway", gateway])
        if dns:
            cmds[1].extend(["ipv4.dns", dns])

        cmds.append(["nmcli", "connection", "up", CONNECTION_NAME])

        for i, cmd in enumerate(cmds):
            result = run_cmd(cmd)
            if result.returncode != 0:
                if i == 0:
                    continue
                raise RuntimeError(result.stderr.strip() or result.stdout.strip() or "Unknown nmcli error")

    def apply_windows_static(self, iface, ip, netmask, gateway, dns):
        try:
            netmask_to_prefix(netmask)
        except Exception as e:
            raise RuntimeError(f"Bad netmask: {e}")

        base_cmd = ["netsh", "interface", "ip", "set", "address", f'name={iface}', "static", ip, netmask]
        if gateway:
            base_cmd.extend([gateway, "1"])
        else:
            base_cmd.extend(["none"])
        result = subprocess.run(base_cmd, capture_output=True, text=True, shell=False)
        if result.returncode != 0:
            raise RuntimeError(result.stderr.strip() or result.stdout.strip() or "netsh failed setting static IP")

        if dns:
            dns_servers = [x.strip() for x in dns.split(",") if x.strip()]
            for server in dns_servers:
                if not is_valid_ipv4(server):
                    raise RuntimeError(f"Bad DNS server: {server}")
            first = subprocess.run(
                ["netsh", "interface", "ip", "set", "dns", f'name={iface}', "static", dns_servers[0], "primary"],
                capture_output=True, text=True, shell=False
            )
            if first.returncode != 0:
                raise RuntimeError(first.stderr.strip() or first.stdout.strip() or "Failed setting primary DNS")
            for idx, server in enumerate(dns_servers[1:], start=2):
                add = subprocess.run(
                    ["netsh", "interface", "ip", "add", "dns", f'name={iface}', server, f"index={idx}"],
                    capture_output=True, text=True, shell=False
                )
                if add.returncode != 0:
                    raise RuntimeError(add.stderr.strip() or add.stdout.strip() or f"Failed adding DNS {server}")

    def set_dhcp(self):
        iface = self.interface_var.get().strip()
        if not iface:
            messagebox.showerror(APP_TITLE, "Choose or type an interface first.")
            return

        try:
            if self.os_name == "Windows":
                self.set_windows_dhcp(iface)
            else:
                self.set_linux_dhcp(iface)

            self.on_save()
            self.status_var.set(f"Returned {iface} to DHCP")
            messagebox.showinfo(APP_TITLE, f"{iface} returned to DHCP.")
        except Exception as e:
            messagebox.showerror(APP_TITLE, f"Failed to set DHCP.\n\n{e}")

    def set_linux_dhcp(self, iface):
        cmds = [
            ["nmcli", "connection", "delete", CONNECTION_NAME],
            [
                "nmcli", "connection", "add",
                "type", "ethernet",
                "ifname", iface,
                "con-name", CONNECTION_NAME,
                "ipv4.method", "auto",
                "ipv6.method", "ignore",
            ],
            ["nmcli", "connection", "up", CONNECTION_NAME],
        ]

        for i, cmd in enumerate(cmds):
            result = run_cmd(cmd)
            if result.returncode != 0:
                if i == 0:
                    continue
                raise RuntimeError(result.stderr.strip() or result.stdout.strip() or "Unknown nmcli error")

    def set_windows_dhcp(self, iface):
        cmds = [
            ["netsh", "interface", "ip", "set", "address", f"name={iface}", "dhcp"],
            ["netsh", "interface", "ip", "set", "dns", f"name={iface}", "dhcp"],
        ]
        for cmd in cmds:
            result = subprocess.run(cmd, capture_output=True, text=True, shell=False)
            if result.returncode != 0:
                raise RuntimeError(result.stderr.strip() or result.stdout.strip() or "netsh failed setting DHCP")


if __name__ == "__main__":
    root = tk.Tk()
    app = CameraIpPickerApp(root)
    root.mainloop()

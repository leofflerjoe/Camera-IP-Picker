#!/bin/bash
LOG="$HOME/.camera_ip_picker.log"

{
  echo "=== $(date) ==="
  echo "Starting Camera IP Picker"
} >> "$LOG"

if ! command -v python3 >/dev/null 2>&1; then
  if command -v zenity >/dev/null 2>&1; then
    zenity --error --text="python3 is not installed."
  fi
  exit 1
fi

python3 "$HOME/Apps/camera_ip_picker_gui.py" >> "$LOG" 2>&1
RC=$?

if [ $RC -ne 0 ]; then
  MSG="Camera IP Picker failed to start.\n\nCheck:\n$HOME/.camera_ip_picker.log"
  if command -v zenity >/dev/null 2>&1; then
    zenity --error --text="$MSG"
  elif command -v xmessage >/dev/null 2>&1; then
    xmessage "$MSG"
  fi
fi

exit $RC

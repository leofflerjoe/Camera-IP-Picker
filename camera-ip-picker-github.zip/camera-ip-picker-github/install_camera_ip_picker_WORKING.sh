#!/bin/bash
set -e

mkdir -p "$HOME/Apps"
cp camera_ip_picker_gui_WORKING.py "$HOME/Apps/camera_ip_picker_gui.py"
cp camera_ip_picker_launcher.sh "$HOME/Apps/camera_ip_picker_launcher.sh"
chmod +x "$HOME/Apps/camera_ip_picker_gui.py"
chmod +x "$HOME/Apps/camera_ip_picker_launcher.sh"

mkdir -p "$HOME/.local/share/applications"
cp "Camera IP Picker WORKING.desktop" "$HOME/.local/share/applications/Camera IP Picker.desktop"
cp "Camera IP Picker Admin WORKING.desktop" "$HOME/.local/share/applications/Camera IP Picker Admin.desktop"
chmod +x "$HOME/.local/share/applications/Camera IP Picker.desktop"
chmod +x "$HOME/.local/share/applications/Camera IP Picker Admin.desktop"

echo
echo "Installed:"
echo "  $HOME/Apps/camera_ip_picker_gui.py"
echo "  $HOME/Apps/camera_ip_picker_launcher.sh"
echo
echo "Menu entries installed:"
echo "  Camera IP Picker"
echo "  Camera IP Picker Admin"
echo
echo "If it still does not open from the menu, run this in Terminal:"
echo "  $HOME/Apps/camera_ip_picker_launcher.sh"
